package com.example.tupikids;

import android.app.AlertDialog;
import android.view.View;

public class Fase {
    AlertDialog ad;
    private Animal animal;
    private Captcha captcha;
    private String tutorial;

    public Fase(Animal animal, Captcha captcha, String tutorial){
        this.animal = animal;
        this.captcha = captcha;
        this.tutorial = tutorial;
    }

    public void mostraTutorial(View view){
        ad.setTitle("Tutorial");
        ad.setMessage("Marque as imagens que têm poluição e depois clique no botão 'Continuar'!");
        ad.show();
    }

}
