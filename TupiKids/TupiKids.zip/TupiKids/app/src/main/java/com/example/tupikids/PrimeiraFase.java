package com.example.tupikids;

public class PrimeiraFase extends Fase{

    public PrimeiraFase(Animal animal, Captcha captcha, String tutorial) {
        super(animal, captcha, tutorial);
    }
}
